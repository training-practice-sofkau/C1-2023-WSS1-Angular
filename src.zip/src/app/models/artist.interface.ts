export interface IArtist{
    id: number,
    name: string,
    country: string,
    age: number,
    year_debut: number,
    total_albums: number,
    pic_url: string;
}
