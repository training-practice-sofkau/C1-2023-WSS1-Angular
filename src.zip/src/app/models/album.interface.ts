export interface IAlbum {
  title: string,
  genre: string,
  release_date: string,
  number_of_songs: number,
  artist: string
}
